import React from "react";
import { DrawerNavigator } from "react-navigation";

import Home from "./components/home/";
import Header from "./components/Header/";

import Login from "./components/login/"
import SignUp from "./components/signup";
import SideBar from "./components/sidebar/";
import Dashboard from "./components/dashboard";
import Attendance from "./components/attendance";
import Tracking from "./components/tracking";
//import Track from "./components/track";
import { isSignedIn } from "./outh/";

checkSignedIn = () =>{
    
   
    let check = isSignedIn();
   
    check
    .then(function whenOk(response) {
    
    return response
    return 'Login'
    })
    .catch(function notOk(err) {
        alert(err)
    })
   // alert("check");
    
}

const DrawerExample = DrawerNavigator(
    {
       
        Header: { screen: Header },
        Home: { screen: Home },
        Login: { screen: Login },
        Dashboard:  { screen: Dashboard},
        Attendance: { screen: Attendance },
        Tracking: { screen: Tracking },
        SignUp: { screen: SignUp },
        

    },
    {
        initialRouteName: 'Attendance',
        contentOptions: {
            activeTintColor: "#e91e63"
    },
        contentComponent: props => <SideBar {...props} />
    }
);


export default DrawerExample;