/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import AppChild from "./js/AppChild";
//import { isLogin } from "./js/models/";
//import { AsyncStorage } from "react-native";



export default class App extends Component {



  constructor() {
    super();
    this.state = {
      isReaddy: false
    };
    
    global.apiurl = 'http://innorade.in/seller/location/';
  }




  render() {
    return <AppChild />;
  }
}
