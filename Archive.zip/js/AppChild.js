import React from "react";

import { Platform } from "react-native";
import { Root } from "native-base";

import { StackNavigator } from "react-navigation";

import Drawer from "./Drawer";

import Header from "./components/Header/";
import Home from "./components/Header/1";
import Login from "./components/login";
import SignUp from "./components/signup";




const AppNavigator =  StackNavigator (
    {
        Drawer: { screen: Drawer },
        Header: { screen: Header },
        Login: { screen: Login },
        SignUp: { screen: SignUp }
    },
    {
        initialRouteName: "Drawer",
        headerMode: "none"
    }
);


export default () =>

<Root>
    <AppNavigator />
</Root>;